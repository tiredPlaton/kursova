﻿
namespace Курсова
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.appTitleLabel = new System.Windows.Forms.Label();
            this.tourButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.currentUserLabel = new System.Windows.Forms.Label();
            this.currentUserTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.navigationFlowLayout = new System.Windows.Forms.FlowLayoutPanel();
            this.autorizeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // appTitleLabel
            // 
            this.appTitleLabel.AutoSize = true;
            this.appTitleLabel.Location = new System.Drawing.Point(24, 38);
            this.appTitleLabel.Name = "appTitleLabel";
            this.appTitleLabel.Size = new System.Drawing.Size(126, 16);
            this.appTitleLabel.TabIndex = 1;
            this.appTitleLabel.Text = "Главная страница";
            // 
            // tourButton
            // 
            this.tourButton.Location = new System.Drawing.Point(584, 88);
            this.tourButton.Name = "tourButton";
            this.tourButton.Size = new System.Drawing.Size(124, 54);
            this.tourButton.TabIndex = 2;
            this.tourButton.Text = "Просмотр информации";
            this.tourButton.UseVisualStyleBackColor = true;
            this.tourButton.Click += new System.EventHandler(this.tourButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 88);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(314, 350);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // currentUserLabel
            // 
            this.currentUserLabel.AutoSize = true;
            this.currentUserLabel.Location = new System.Drawing.Point(442, 35);
            this.currentUserLabel.Name = "currentUserLabel";
            this.currentUserLabel.Size = new System.Drawing.Size(193, 16);
            this.currentUserLabel.TabIndex = 4;
            this.currentUserLabel.Text = "Действующий пользователь";
            // 
            // currentUserTextBox
            // 
            this.currentUserTextBox.Location = new System.Drawing.Point(660, 32);
            this.currentUserTextBox.Name = "currentUserTextBox";
            this.currentUserTextBox.ReadOnly = true;
            this.currentUserTextBox.Size = new System.Drawing.Size(100, 22);
            this.currentUserTextBox.TabIndex = 5;
            this.currentUserTextBox.Text = "User";
            // 
            // exitButton
            // 
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Location = new System.Drawing.Point(584, 344);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(144, 62);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Выход из программы";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // navigationFlowLayout
            // 
            this.navigationFlowLayout.Location = new System.Drawing.Point(584, 166);
            this.navigationFlowLayout.Name = "navigationFlowLayout";
            this.navigationFlowLayout.Size = new System.Drawing.Size(176, 99);
            this.navigationFlowLayout.TabIndex = 7;
            // 
            // autorizeButton
            // 
            this.autorizeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.autorizeButton.Location = new System.Drawing.Point(350, 357);
            this.autorizeButton.Name = "autorizeButton";
            this.autorizeButton.Size = new System.Drawing.Size(103, 49);
            this.autorizeButton.TabIndex = 8;
            this.autorizeButton.Text = "Войти";
            this.autorizeButton.UseVisualStyleBackColor = true;
            this.autorizeButton.Click += new System.EventHandler(this.autorizeButton_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 508);
            this.Controls.Add(this.autorizeButton);
            this.Controls.Add(this.navigationFlowLayout);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.currentUserTextBox);
            this.Controls.Add(this.currentUserLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tourButton);
            this.Controls.Add(this.appTitleLabel);
            this.Name = "Main";
            this.Text = "  ";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label appTitleLabel;
        private System.Windows.Forms.Button tourButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label currentUserLabel;
        private System.Windows.Forms.TextBox currentUserTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.FlowLayoutPanel navigationFlowLayout;
        private System.Windows.Forms.Button autorizeButton;
    }
}