﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Курсова
{
    public partial class Logon : Form
    {
        int tries;
        public bool isAdmin;
        public string username;
        public string password;
        public Logon()
        {
            InitializeComponent();
            tries = 0;
            username = "";
            password = "";
        }

        private void OK_Click(object sender, EventArgs e)
        {
            username = usernameTextBox.Text;
            password = passwordTextBox.Text;

            if (username == "Admin" && password == "Admin")
            {
                isAdmin = true;
                this.Close();
            }
            else
            {
                usernameTextBox.Text = "";
                passwordTextBox.Text = "";
                usernameTextBox.Focus();
                tries++;
                if (tries == 3)
                {
                    OK.Enabled = false;
                    isAdmin = false;
                    username = "";
                    password = "";
                    MessageBox.Show("You have failed to login three times in a row. The login form will be closed.", "Too many incorrect attempts");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Incorrect username or password", "Login error");
                }
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Logon_Load(object sender, EventArgs e)
        {

        }

        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
