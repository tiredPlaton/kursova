﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Курсова
{
    public partial class Main : Form
    {
        Button userAdminButton;
        public Main()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Main_Load(object sender, EventArgs e)
        {            

        }
        private void userAdminButton_Click(object sender, EventArgs e)
        {
            try
            {
                Form newAddInformation = new AddInformation();
                newAddInformation.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error encountered", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void exitButton_MouseEnter(object sender, EventArgs e)
        {
            exitButton.BackColor = Color.Green;
        }

        private void exitButton_MouseLeave(object sender, EventArgs e)
        {
            exitButton.BackColor = Color.White;
        }

        private void autorizeButton_Click(object sender, EventArgs e)
        {
            Logon logon = new Logon();
            logon.ShowDialog(this);
            try
            {
                if (logon.username != "")
                {
                    currentUserTextBox.Text = logon.username;
                    if (logon.isAdmin)
                    {
                        userAdminButton = new Button();
                        userAdminButton.Name = "UserAdminButton";
                        userAdminButton.Text = "Добавление информации";
                        userAdminButton.Width = 113;
                        userAdminButton.Height = 55;

                        navigationFlowLayout.Controls.Add(userAdminButton);

                        userAdminButton.Click += userAdminButton_Click;
                    }
                }
                else
                {
                    System.Environment.Exit(0);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error encountered", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void tourButton_Click(object sender, EventArgs e)
        {
            try
            {
                Form newInformation = new Information();
                newInformation.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error encountered", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
