USE [master]
GO

/****** Object:  Database [Testbase]    Script Date: 12/14/2023 10:16:53 PM ******/
DROP DATABASE [Testbase]
GO

