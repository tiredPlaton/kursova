SELECT COUNT(DISTINCT Passenger) AS TotalPassengers FROM TicketInfo;
