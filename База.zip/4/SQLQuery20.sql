SELECT SUM(Price) AS TotalMoney FROM TicketInfo;
