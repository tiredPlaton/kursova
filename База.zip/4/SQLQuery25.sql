SELECT Passenger, Name, MAX(PassportDate) AS LastPassportDate
FROM PassengerInfo
GROUP BY Passenger, Name;
