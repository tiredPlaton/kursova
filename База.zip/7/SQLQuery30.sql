SELECT *
FROM TrainInfo
WHERE Train IN (SELECT DISTINCT Train FROM TicketInfo);
