SELECT *
FROM TicketInfo
WHERE Passenger = (
    SELECT Passenger
    FROM PassengerInfo
    WHERE Name = 'Jane Doe'
);
