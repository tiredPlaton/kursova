CREATE PROCEDURE UpdateTicketPrice
    @TicketId INT,
    @NewPrice DECIMAL(6,2) OUTPUT
AS
BEGIN
    UPDATE TicketInfo
    SET Price = @NewPrice
    WHERE Ticket = @TicketId;

    SET @NewPrice = (SELECT Price FROM TicketInfo WHERE Ticket = @TicketId);
END;
