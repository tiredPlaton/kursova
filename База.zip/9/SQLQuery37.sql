EXEC GetTicketsByPassenger @PassengerId = 1;
