CREATE PROCEDURE GetTicketsByPassenger
    @PassengerId INT
AS
BEGIN
    SELECT *
    FROM TicketInfo
    WHERE Passenger = @PassengerId;
END;
