Use Testbase
-- Inserting sample data into TrainInfo table
INSERT INTO TrainInfo (Passage, Title, Date, Time, Arrival, ArrivalTime, Seats, Places, Train, TrainName, Year, Picture, Amount, Admin)
VALUES
(1, 'Express 1', '2023-12-15', '08:00:00', '2023-12-15', '12:00:00', 1, 'StationA, StationB, StationC', 101, 'Express-A', 2020, 'path/to/picture1.jpg', 100, 'Smith'),
(2, 'Fast Train', '2023-12-16', '10:30:00', '2023-12-16', '14:30:00', 0, NULL, 102, 'Fast-Train', 2019, 'path/to/picture2.jpg', 80, 'Johnson'),
(3, 'City Connect', '2023-12-17', '15:45:00', '2023-12-17', '19:30:00', 1, 'StationX, StationY', 103, 'City-Connect', 2022, 'path/to/picture3.jpg', 120, 'Williams'),
(4, 'Local Express', '2023-12-18', '12:15:00', '2023-12-18', '16:30:00', 1, 'StationP, StationQ, StationR', 104, 'Local-Express', 2021, 'path/to/picture4.jpg', 90, 'Brown'),
(5, 'Night Rider', '2023-12-19', '21:00:00', '2023-12-20', '05:00:00', 1, 'StationM, StationN', 105, 'Night-Rider', 2018, 'path/to/picture5.jpg', 150, 'Taylor');
