Use Testbase
-- Inserting sample data into TicketInfo table
INSERT INTO TicketInfo (Till, Ticket, Chair, TrainCar, Class, Price, Registrar, Passenger)
VALUES
(1, 10101, 15, 1, 1, 50.00, 'Johnson', 1),
(2, 10102, 8, 2, 2, 75.50, 'Smith', 2),
(3, 10103, 20, 1, 1, 60.25, 'Brown', 3),
(4, 10104, 10, 2, 1, 55.75, 'Taylor', 4),
(5, 10105, 5, 3, 2, 80.00, 'Williams', 5),
(6, 10106, 12, 1, 1, 65.50, 'Smith', 6);
