Use Testbase
-- Inserting sample data into CrewInfo table
INSERT INTO CrewInfo (Crew, Pilot, CrewNames, Train)
VALUES
(1, 'John Anderson', 'Maria Davis, Richard Harris', 1),
(2, 'Emma White', 'Daniel Robinson, Sarah Johnson', 2),
(3, 'Christopher Martin', 'Olivia Taylor, James Miller', 3),
(4, 'Jessica Smith', 'Michael Brown, Emily White', 4),
(5, 'David Johnson', 'Sophia Miller, Matthew Davis', 5);
