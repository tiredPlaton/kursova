Use Testbase
-- Inserting sample data into PassengerInfo table
INSERT INTO PassengerInfo (Passenger, Name, Date, Passport, PassportDate, Region)
VALUES
(1, 'John Smith', '1990-05-15', 'ABC123456', '2010-05-20', 'CityA'),
(2, 'Jane Doe', '1985-08-22', 'XYZ789012', '2009-10-15', 'CityB'),
(3, 'Robert Johnson', '1978-12-10', 'PQR567890', '2005-03-18', 'CityC'),
(4, 'Emily White', '1993-07-08', 'LMN456789', '2011-02-28', 'CityD'),
(5, 'Michael Brown', '1982-04-25', 'DEF987654', '2008-09-10', 'CityE'),
(6, 'Sophia Miller', '1995-11-30', 'GHI321098', '2012-07-15', 'CityF');
