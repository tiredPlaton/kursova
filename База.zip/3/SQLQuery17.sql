SELECT * FROM CrewInfo WHERE Pilot = 'John Anderson';
