SELECT * FROM TrainInfo WHERE Arrival > '2023-01-01';
