SELECT * FROM PassengerInfo WHERE Region = 'CityA';
