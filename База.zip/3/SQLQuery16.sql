SELECT * FROM TicketInfo WHERE Price > 50.00;

