CREATE TRIGGER CreateCustomerInfoTrigger
ON PassengerInfo
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO CustomerInfo (CustomerId, CustomerName, RegistrationDate)
    SELECT
        i.Passenger,
        i.Name,
        GETDATE()
    FROM
        INSERTED i;
END;
