UPDATE PassengerInfo
SET Name = 'Valentin'
WHERE Passenger = 123;
