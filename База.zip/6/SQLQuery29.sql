DELETE FROM TicketInfo
WHERE Passenger = 456;
