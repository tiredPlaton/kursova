CREATE VIEW TicketInfoView AS
SELECT
    T.Till,
    T.Ticket,
    T.Chair,
    T.TrainCar,
    T.Class,
    T.Price,
    T.Registrar,
    P.Passenger,
    P.Name AS PassengerName,
    P.Region
FROM TicketInfo T
JOIN PassengerInfo P ON T.Passenger = P.Passenger;
