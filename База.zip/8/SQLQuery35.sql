SELECT *
FROM TicketInfo
WHERE Price > (SELECT AVG(Price) FROM TicketInfo);
