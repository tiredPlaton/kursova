SELECT
    T.Till,
    T.Ticket,
    T.Chair,
    T.TrainCar,
    T.Class,
    T.Price,
    T.Registrar,
    P.Passenger,
    P.Name AS PassengerName,
    P.Region
FROM TicketInfo AS T
JOIN PassengerInfo AS P ON T.Passenger = P.Passenger;
